=== Profit Button ===
Contributors: hintsolutions
Donate link: -
Tags: widget, profit button, floating button, interctive element, custom, plugin, servey, advertising, monetization, probtn, button, feedback, analytics, vote, voting, content, feed, marketing
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: trunk
License: Licenced under LGPL
License URI: http://opensource.org/licenses/LGPL-3.0

Floating button for you site or blog, which can give you opportunity to make a survey, show ads and collect some statistics about user.

== Description ==

Profit button is a new way to add survey, ads or some other additional content without adding any changes to your design.

Functionality is implemented like floating button above your site, and after clicking on button would be opened additional modal window with nessesary content.

For better usability users can use admin panel with settings and button targeting, and also some detailed statistics and analytics.

== Installation ==

1. Upload `probtn` folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Register or login at admin.probtn.com and add your site in apps list, to get opportunity to set params for floating button.

== Frequently asked questions ==



== Screenshots ==

1. https://dl.dropboxusercontent.com/u/3482508/site_button_image/example1.png
2. https://dl.dropboxusercontent.com/u/3482508/site_button_image/example2.png
3. https://dl.dropboxusercontent.com/u/3482508/site_button_image/example3.png

== Changelog ==

Added base functionality of floating button.

== Upgrade notice ==



== Arbitrary section 1 ==

