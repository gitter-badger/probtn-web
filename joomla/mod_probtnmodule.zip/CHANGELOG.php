<?php
/**
 * CHANGELOG
 *
 * This is the changelog for probtnmodule.<br>
 * <b>Please</b> be patient =;)
 *
 * @version    SVN $Id$
 * @package    probtnmodule
 * @subpackage Documentation
 * @author     hintsolutions {@link hhttp://m0rg0t.com}
 * @author     Created on 04-Nov-2013
 */

//--No direct access to this changelog...
defined('_JEXEC') || die('=;)');

//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG()
{
/*
_______________________________________________
_______________________________________________

This is the changelog for probtnmodule

Please be patient =;)
_______________________________________________
_______________________________________________

Legend:

 * -> Security Fix
 # -> Bug Fix
 + -> Addition
 ^ -> Change
 - -> Removed
 ! -> Note
______________________________________________

04-Nov-2013 hintsolutions
 ! Startup

*/
}//--This is the END
